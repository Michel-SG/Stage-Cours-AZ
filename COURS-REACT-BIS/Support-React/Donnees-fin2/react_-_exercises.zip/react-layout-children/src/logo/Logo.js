import React, { Component } from "react";

import "./Logo.css";

export default class Logo extends Component {
    render() {
        return (
            <div>
                <img src="/images/react.png" />
            </div>
        );
    }
}
