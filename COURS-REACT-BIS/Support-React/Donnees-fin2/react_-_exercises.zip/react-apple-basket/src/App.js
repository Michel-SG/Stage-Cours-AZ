import React from "react";
import logo from "./logo.svg";
import "./App.css";
import AppleBasket from "./AppleBasket";

function App() {
    return (
        <div className="App">
            <AppleBasket />
        </div>
    );
}

export default App;
