import React, { Component } from "react";

import "./Main.css";

export default class Main extends Component {
    render() {
        return (
            <main>
                <h1>Bienvenue sur mon site web !</h1>
                <hr />
                <p>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                    Earum esse praesentium repudiandae aut ipsa cum, atque
                    assumenda quod, vero, iusto sit! Mollitia obcaecati
                    accusamus tempora veniam illum nisi adipisci. Repellat!
                </p>
            </main>
        );
    }
}
