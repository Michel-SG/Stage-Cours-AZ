export const ADD_TASKLIST = "ADD_TASKLIST";
export const EDIT_TASKLIST = "EDIT_TASKLIST";
export const ADD_TASK = "ADD_TASK";
export const EDIT_TASK = "EDIT_TASK";
export const DELETE_TASK = "DELETE_TASK";
