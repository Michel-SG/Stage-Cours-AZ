import React from 'react';

export default function withToggler(WrappedComponent) {
    return class extends React.Component {
        constructor(props) {
            super(props);

            this.state = {
                hide: false,
            };
        }

        handleToggle = () => {
            this.setState((state) => ({ hide: !state.hide }));
        };

        render() {
            const { hide } = this.state;

            return (
                <div className="toggler">
                    <h2 className="toggler-action" onClick={this.handleToggle}>
                        Toggle
                    </h2>

                    <hr />

                    <div className={hide ? 'hide' : ''}>
                        <WrappedComponent />
                    </div>
                </div>
            );
        }
    };
}
