import React from 'react';
import './App.css';
import AppleBasket from './AppleBasket';

function App() {
    return <AppleBasket />;
}

export default App;
