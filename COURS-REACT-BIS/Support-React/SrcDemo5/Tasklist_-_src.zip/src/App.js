import Tasklist from './Tasklist';

import './App.css';

function App() {
    return (
        <div className='App'>
            <Tasklist />
        </div>
    );
}

export default App;
